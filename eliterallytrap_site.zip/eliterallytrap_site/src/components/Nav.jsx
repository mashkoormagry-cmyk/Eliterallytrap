import React from 'react'
import { NavLink } from 'react-router-dom'

export default function Nav(){
  return (
    <nav className="bg-white shadow p-4 rounded-2xl max-w-5xl mx-auto flex items-center justify-between">
      <div className="flex items-center gap-4">
        <div className="font-bold text-xl">Eliterallytrap</div>
        <div className="text-sm text-gray-500">Lords Mobile • War Rallies</div>
      </div>
      <div className="flex gap-3">
        <NavLink to="/" className={({isActive}) => isActive ? 'text-purple-600 font-semibold' : 'text-gray-700'}>Home</NavLink>
        <NavLink to="/videos" className={({isActive}) => isActive ? 'text-purple-600 font-semibold' : 'text-gray-700'}>Videos</NavLink>
        <NavLink to="/starpromo" className={({isActive}) => isActive ? 'text-purple-600 font-semibold' : 'text-gray-700'}>Star Promo</NavLink>
        <NavLink to="/about" className={({isActive}) => isActive ? 'text-purple-600 font-semibold' : 'text-gray-700'}>About</NavLink>
        <NavLink to="/contact" className={({isActive}) => isActive ? 'text-purple-600 font-semibold' : 'text-gray-700'}>Contact</NavLink>
      </div>
    </nav>
  )
}
