import React from 'react'

export default function Home(){
  const featuredVideoEmbed = 'https://www.youtube.com/embed?listType=user_uploads&list=Eliterallytrap'

  return (
    <div className="space-y-6">
      <section className="bg-white p-6 rounded-2xl shadow">
        <h1 className="text-2xl font-bold">Welcome to Eliterallytrap</h1>
        <p className="text-gray-600">Lords Mobile war rally highlights, traps, and KvK action — straight from the YouTube channel.</p>
      </section>

      <section className="bg-white p-6 rounded-2xl shadow">
        <h2 className="text-xl font-semibold mb-3">Featured — Latest Uploads</h2>
        <div className="aspect-video w-full rounded-xl overflow-hidden">
          <iframe className="w-full h-full" src={featuredVideoEmbed} title="Latest uploads" frameBorder="0" allowFullScreen allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"></iframe>
        </div>
      </section>

      <section className="bg-white p-6 rounded-2xl shadow">
        <h2 className="text-xl font-semibold mb-3">Quick Links</h2>
        <ul className="list-disc pl-5 text-gray-700">
          <li>All Videos</li>
          <li>Star Promoter Code: <strong>Eliterallytrap</strong></li>
        </ul>
      </section>
    </div>
  )
}
