import React from 'react'

export default function Contact(){
  return (
    <div className="space-y-6">
      <section className="bg-white p-6 rounded-2xl shadow">
        <h1 className="text-2xl font-bold">Contact</h1>
        <p className="text-gray-600">Business inquiries, collaborations, or questions — reach out on YouTube or use the email below.</p>
        <p className="mt-4">Email: <strong>mashkoor342@gmail.com</strong></p>
      </section>
    </div>
  )
}
