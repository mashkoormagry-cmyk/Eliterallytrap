import React from 'react'

export default function StarPromo(){
  return (
    <div className="space-y-6">
      <section className="bg-gradient-to-r from-purple-600 to-indigo-600 text-white p-6 rounded-2xl shadow">
        <h1 className="text-2xl font-bold">Lords Mobile — Star Promoter Code</h1>
        <p className="mt-2">Use this code when creating a new account to support the channel and get bonuses.</p>

        <div className="mt-6 bg-white text-purple-700 rounded-xl p-4 text-center text-2xl font-extrabold">Eliterallytrap</div>

        <p className="mt-4 text-sm">Tip: New players should enter the code within 6 hours of account creation to receive the registration bonus.</p>
      </section>

      <section className="bg-white p-6 rounded-2xl shadow">
        <h2 className="text-xl font-semibold">How to Enter the Code</h2>
        <ol className="list-decimal pl-5 mt-2 text-gray-700">
          <li>Create a new Lords Mobile account on your device.</li>
          <li>Open the Star Promoter / Invite code area in the game.</li>
          <li>Enter <strong>Eliterallytrap</strong> and confirm.</li>
        </ol>
      </section>
    </div>
  )
}
