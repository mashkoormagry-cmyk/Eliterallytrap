import React from 'react'

export default function Videos(){
  const playlistEmbed = 'https://www.youtube.com/embed?listType=user_uploads&list=Eliterallytrap'

  return (
    <div className="space-y-6">
      <section className="bg-white p-6 rounded-2xl shadow">
        <h1 className="text-2xl font-bold">All Videos</h1>
        <p className="text-gray-600">Watch every upload from the channel.</p>
      </section>

      <section className="bg-white p-6 rounded-2xl shadow">
        <div className="aspect-video w-full rounded-xl overflow-hidden">
          <iframe className="w-full h-full" src={playlistEmbed} title="All videos" frameBorder="0" allowFullScreen allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"></iframe>
        </div>
      </section>
    </div>
  )
}
