import React from 'react'

export default function About(){
  return (
    <div className="space-y-6">
      <section className="bg-white p-6 rounded-2xl shadow">
        <h1 className="text-2xl font-bold">About Eliterallytrap</h1>
        <p className="text-gray-600">I create Lords Mobile war videos focused on rally highlights, traps, and tactics. Subscribe on YouTube: <a className="text-purple-600" href="https://youtube.com/@eliterallytrap" target="_blank" rel="noreferrer">Eliterallytrap</a>.</p>
      </section>

      <section className="bg-white p-6 rounded-2xl shadow">
        <h2 className="text-xl font-semibold">What I Share</h2>
        <ul className="list-disc pl-5 text-gray-700">
          <li>War rally highlights</li>
          <li>Trap tactics and analysis</li>
          <li>Thumbnails & content tips for Lords Mobile creators</li>
        </ul>
      </section>
    </div>
  )
}
